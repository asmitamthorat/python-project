#from django.urls import path
from app1 import views
from django.urls import path, include

from rest_framework.routers import DefaultRouter


router = DefaultRouter()
router.register('hello-viewset', views.HelloViewSet, basename='hello-viewset')
router.register('profile',views.UserProfileViewSet)

urlpatterns = [
    path('1/', views.HelloApiView.as_view()),
    #path('web/',include('app1.urls'))
    #path('2/',views.HelloViewSet.as_view())
    path('', include(router.urls)),
]
